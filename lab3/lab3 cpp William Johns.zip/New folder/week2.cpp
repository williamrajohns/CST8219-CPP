
#include<iostream>

using namespace std;

class Vehicle {
private:
	int numWheels;
	int numDoors;
public:
	Vehicle() : Vehicle(4) {
		cout << "In constuctor with 0 parameters" << endl;
	}
	Vehicle(int w) : Vehicle(4, w) {
		
		cout << "In constuctor with 1 parameters, wheels = "<< w << endl;
	}
	Vehicle(int d, int w) {
		numWheels = w;
		numDoors = d;
		cout << "In constuctor with 2 parameters, doors = " << d << " wheels = " << w << endl;
	}

	~Vehicle() { 
		cout << "In destuctor" << endl;
	}
};

int main(int argc, char **argv)
{
	Vehicle veh1;
	Vehicle veh2(4);
	Vehicle veh3(4, 2);

	Vehicle* pVehicle; 
	int w, d;
	int isCreated = 0;
	string whatDo = "a";


	do {
		cout << "What would you like to do? " << endl;
		cout << "To create new vehicle type: n " << endl;
		cout << "To quit type: q " << endl;
		cin >> whatDo;
		if (whatDo == "n") {
			if (isCreated == 1)
			{
				delete pVehicle;
				isCreated = 0;
			}
			cout << "Enter number of doors " << endl;
			while (!(cin >> d && d >  0)) {
				cout << "Not a valid number above 0 " << endl;
				cout << "Enter number of doors " << endl;
				cin.clear();
				cin.ignore(256, '\n');
			}

			cout << "Enter number of wheels " << endl;
			while (!(cin >> w && w > 0)) {
				cout << "Not a valid number above 0 " << endl;	\
				cout << "Enter number of wheels " << endl;
				cin.clear();
				cin.ignore(256, '\n');
			}
			
			pVehicle = new Vehicle(d, w);
			isCreated = 1;
		}
		else if (whatDo == "q") {
			if (isCreated == 1)
			{
				delete pVehicle;
			}
			break;
		}
		else {
			cout << "Not a valid input" << endl;
		}
		whatDo = "a";
	} while (whatDo != "q");

	cout << "I made a vehicle" << endl;
	
	cout << "Vehicle takes " << sizeof(veh1) << endl;
	cout << "Vehicle takes " << sizeof(veh2) << endl;
	cout << "Vehicle takes " << sizeof(veh3) << endl;
	cout << "isCreated takes " << sizeof(isCreated) << endl;
	cout << "d takes " << sizeof(d) << endl;
	cout << "w takes " << sizeof(w) << endl;
	cout << "pVehicle takes " << sizeof(Vehicle*) << endl;
	cout << "whatDo takes " << sizeof(whatDo) << endl;

	return 0;
}