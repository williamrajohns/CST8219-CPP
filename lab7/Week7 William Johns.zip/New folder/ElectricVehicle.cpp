#pragma once
#include <iostream>
#include "ElectricVehicle.h"

using namespace std;
/*
template <class T>
ElectricVehicle<T>::ElectricVehicle() : ElectricVehicle(0, 0) {

}

template <class T>
ElectricVehicle<T>::ElectricVehicle(T max, T efficiency) {
	maximumCharge = max;
	currentCharge = maximumCharge;
	engineEfficiency = efficiency;
}

template <class T>
ElectricVehicle<T>::~ElectricVehicle() {
	cout << "In Electric Destructor" << endl;   //Change ClassName to either Vehicle, Hybrid, Gasoline, Electric,
}

template <class T>
float ElectricVehicle<T>::calculateRange() {
	return currentCharge * 100 / engineEfficiency;
}

template <class T>
float ElectricVehicle<T>::percentEnergyRemaining() {
	return currentCharge / maximumCharge * 100.0f;
}

template <class T>
void ElectricVehicle<T>::drive(float km) {
	currentCharge -= (km / 100) * engineEfficiency;
}

*/