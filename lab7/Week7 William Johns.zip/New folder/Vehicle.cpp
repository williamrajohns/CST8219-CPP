#include <iostream>
#include "Vehicle.h"

using namespace std;

/* copied in lab 7


template <class T>
Vehicle<T>::Vehicle() : Vehicle(0, 1) {
	//cout << "In constuctor with 0 parameters" << endl;
}

template <class T>
Vehicle<T>::Vehicle(int w) : Vehicle(4, w) {
	//	cout << "In constuctor with 1 parameters, wheels = " << w << endl;
}

template <class T>
Vehicle<T>::Vehicle(int d, int w) {
	numWheels = w;
	numDoors = d;
//	cout << "In constuctor with 2 parameters, doors = " << d << " wheels = " << w << endl;
}

template <class T>
Vehicle<T>::~Vehicle() {
	cout << "In Vehicle Destructor" << endl;   //Change ClassName to either Vehicle, Hybrid, Gasoline, Electric,
}

template <class T>
Vehicle<T>::Vehicle(Vehicle& copy) {
	cout << "In copy by reference constuctor " << endl;
	numDoors = copy.numDoors;
	numWheels = copy.numWheels;
}

template <class T>
Vehicle<T>::Vehicle(Vehicle* copy) :Vehicle(copy->numDoors, copy->numWheels) {
	cout << "In copy by pointer constuctor " << endl;
}

template <class T>
void Vehicle<T>::printVehicle(void) {
	cout << "pv: wheels: " << numWheels << " doors: " << numDoors << endl;
}

*/

// ----- lab6 -----
//copy pasted into the header file
	/*
	Vehicle::Vehicle() : Vehicle(4) {
		cout << "In constuctor with 0 parameters" << endl;
	}
	Vehicle::Vehicle(int w) : Vehicle(4, w) {

		cout << "In constuctor with 1 parameters, wheels = " << w << endl;
	}
	Vehicle::Vehicle(int d, int w) {
		numWheels = w;
		numDoors = d;
		cout << "In constuctor with 2 parameters, doors = " << d << " wheels = " << w << endl;
	}

	Vehicle::~Vehicle() {
		cout << "In destuctor" << endl;
	}
	*/
