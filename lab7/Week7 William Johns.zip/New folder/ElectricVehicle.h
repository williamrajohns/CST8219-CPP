#pragma once
#include "Vehicle.h"

template <class T>
class ElectricVehicle :  public Vehicle<T> {
	T currentCharge;
	T maximumCharge;

public:
	inline ElectricVehicle() : ElectricVehicle(0, 0) {

	}
	
	inline ElectricVehicle(T max, T efficiency) {
		maximumCharge = max;
		currentCharge = maximumCharge;
		engineEfficiency = efficiency;
	}

	inline ~ElectricVehicle() {
		cout << "In Electric Destructor" << endl;   //Change ClassName to either Vehicle, Hybrid, Gasoline, Electric,
	}
	inline T calculateRange() {
		return currentCharge * 100 / engineEfficiency;
	}
	
	inline T percentEnergyRemaining() {
		return (T)(currentCharge / maximumCharge * 100.0f);
	}

	inline void drive(float km) {
		currentCharge -= (T)(km / 100) * engineEfficiency;
	}
};
