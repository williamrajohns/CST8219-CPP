#pragma once
#include "Vehicle.h"
#include "ElectricVehicle.h"
#include "GasolineVehicle.h"

template <class T>
class HybridVehicle : public GasolineVehicle<T>, public ElectricVehicle<T> {

	T currentCharge;
	T maximumCharge;
	T currentGasoline;
	T maximumGasoline;

public:
	inline HybridVehicle() : HybridVehicle(0, 0, 0, 0) {

	}

	inline HybridVehicle(T maxGas, T efficiencyGas, T maxEle, T efficiencyEle) {
		//gas
		maximumGasoline = maxGas;
		currentGasoline = maxGas;
		GasolineVehicle::engineEfficiency = efficiencyGas;
		//electric
		maximumCharge = maxEle;
		currentCharge = maxEle;
		ElectricVehicle::engineEfficiency = efficiencyEle;
	}

	inline ~HybridVehicle() {
		cout << "In Hybrid Destructor" << endl;   //Change ClassName to either Vehicle, Hybrid, Gasoline, Electric,
	}
	
	inline T calculateRange() { //not sure what formula to use
		return ((currentGasoline * 100) / GasolineVehicle::engineEfficiency) + ((currentCharge * 100) / ElectricVehicle::engineEfficiency);
	}
	
	inline T percentEnergyRemaining() {
		return ((currentGasoline / maximumGasoline * 100.0f) + (currentCharge / maximumCharge * 100.0f)) / 2;
	}

	inline void drive(float km) {
		double change = 0;
		if (currentCharge > 0) { //if it has a charge
			change = (km / 100) * ElectricVehicle::engineEfficiency; //check to see if the change of charge would make it negative
			if (change >= currentCharge) { //if it would make it negative
				change -= currentCharge; //remove the part from currentCharge
				currentCharge = 0; //set the new currentCharge to 0 (as the change would make it negative)
			}
			else  //else the change doesn't make it negative
			{
				currentCharge -= change; //reduce charge by the change
				change = 0; //set change to 0;
			}
		}

		if (change > 0) { //if there is still a change left 
			cout << "Your car is out of energy!" << endl;
			double newkm = change * 100 / ElectricVehicle::engineEfficiency;
			currentGasoline -= (T)(newkm / 100) * GasolineVehicle::engineEfficiency;
		}
	}
};



