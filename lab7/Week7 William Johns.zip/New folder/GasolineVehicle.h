#pragma once
#include "Vehicle.h"

template <class T>
class GasolineVehicle: public Vehicle<T> {
	T currentGasoline;
	T maximumGasoline;

public:
	
	inline GasolineVehicle() : GasolineVehicle(0, 0) {

	}
	
	inline GasolineVehicle(T max, T efficiency) {
		maximumGasoline = max;
		currentGasoline = maximumGasoline;
		engineEfficiency = efficiency;
	}

	inline ~GasolineVehicle() {
		cout << "In Gasoline Destructor" << endl;   //Change ClassName to either Vehicle, Hybrid, Gasoline, Electric,
	}

	inline T calculateRange() {
		return currentGasoline * 100 / engineEfficiency;
	}

	inline T percentEnergyRemaining() {
		return currentGasoline / maximumGasoline * 100.0f;
	}

	inline void drive(float km) {
		currentGasoline -= (km / 100) * engineEfficiency;
	}

};


