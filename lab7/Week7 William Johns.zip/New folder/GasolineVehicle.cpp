#pragma once
#include <iostream>
#include "GasolineVehicle.h"

using namespace std;
/*
template <class T>
GasolineVehicle<T>::GasolineVehicle() : GasolineVehicle(0, 0) {

}
template <class T>
GasolineVehicle<T>::GasolineVehicle(T max, T efficiency) {
	maximumGasoline = max;
	currentGasoline = maximumGasoline;
	engineEfficiency = efficiency;
}

template <class T>
GasolineVehicle<T>::~GasolineVehicle() {
	cout << "In Gasoline Destructor" << endl;   //Change ClassName to either Vehicle, Hybrid, Gasoline, Electric,
}


template <class T>
float GasolineVehicle<T>::calculateRange() {
	return currentGasoline * 100 / engineEfficiency;
}

template <class T>
float GasolineVehicle<T>::percentEnergyRemaining() {
	return currentGasoline / maximumGasoline * 100.0f;
}

template <class T>
void GasolineVehicle<T>::drive(float km) {
	currentGasoline -= (km / 100) * engineEfficiency;
}
*/