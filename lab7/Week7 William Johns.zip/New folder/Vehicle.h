#pragma once
template<class T>
class Vehicle {

private:
	int numWheels;
	int numDoors;

public:
	T engineEfficiency = 0; //recheck this - set to 0 as default 
	
	inline Vehicle() : Vehicle(0, 1) {
		//cout << "In constuctor with 0 parameters" << endl;
	}

	inline Vehicle(int w) : Vehicle(4, w) {
		//	cout << "In constuctor with 1 parameters, wheels = " << w << endl;
	}

	inline Vehicle(int d, int w) {
		numWheels = w;
		numDoors = d;
		//	cout << "In constuctor with 2 parameters, doors = " << d << " wheels = " << w << endl;
	}

	inline ~Vehicle() {
		cout << "In Vehicle Destructor" << endl;   //Change ClassName to either Vehicle, Hybrid, Gasoline, Electric,
	}

	inline Vehicle(Vehicle& copy) {
		cout << "In copy by reference constuctor " << endl;
		numDoors = copy.numDoors;
		numWheels = copy.numWheels;
	}

	inline Vehicle(Vehicle* copy) :Vehicle(copy->numDoors, copy->numWheels) {
		cout << "In copy by pointer constuctor " << endl;
	}

	inline void printVehicle(void) {
		cout << "pv: wheels: " << numWheels << " doors: " << numDoors << endl;
	}

	//outstream
	inline friend std::ostream& operator<<(std::ostream& output, const Vehicle<T>& v)
	{
		return cout << " wheels: " << v.numWheels << " doors: " << v.numDoors << endl;;
	}
	
	//copy 
	inline Vehicle<T>& operator=(const Vehicle<T>& v) {
		numWheels = v.numWheels;
		numDoors = v.numDoors;
		return *this;
	}

	//equal/not equal
	inline friend bool operator==(const Vehicle<T>& v1, const Vehicle<T>& v2) {
		return (v1.numWheels == v2.numWheels && v1.numDoors == v2.numDoors); //true if it the condition is true	
	}
	inline friend bool operator!=(const Vehicle<T>& v1, const Vehicle<T>& v2) {
		return !(v1 == v2); //returns negation
	}

	//increment pre and post
	inline Vehicle<T>& operator++() {
		numDoors++;
		numWheels++;
		return *this;
	}
	
	inline Vehicle<T>& operator++(int) {
		Vehicle& temp(*this);
		++(*this);
		return temp;
	}

	//decrement pre and post
	inline Vehicle<T>& operator--() {
		numDoors--;
		numWheels--;
		return *this;
	}

	inline Vehicle<T>& operator--(int) {
		Vehicle& temp(*this);
		--(*this);
		return temp;
	}

	inline T Vehicle<T>::calculateRange() {
		return 0;
	}

	inline T Vehicle<T>::percentEnergyRemaining() {
		return 0;
	}

	inline void Vehicle<T>::drive(float km) {
		return;
	}
};
