﻿// Week 1.cpp : Defines the entry point for the application.
// William Johns, Student number 040832509
#include "Week 1.h"


#define usingNameSpaces 0

// submission is the CMakeLists.txt from the folder Week 1 
#if usingNameSpaces == 0
using namespace std; 
int main()
{
	cout << "Hello world!" << endl;
#pragma message("Using namespaces")
	return 0;
}
#elif usingNameSpaces == 1
int main()
{
	std::cout << "Hello world!" << std::endl;
#pragma message("Not using namespaces")
	return 0;
}
#endif
