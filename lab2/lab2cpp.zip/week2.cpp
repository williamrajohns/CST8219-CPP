
#include<iostream>

using namespace std;

class Vehicle {
private:
	int numWheels;
	int numDoors;
public:
	Vehicle() : Vehicle(4) {
		//sets 
		cout << "In constuctor with 0 parameters" << endl;
	}
	Vehicle(int w) : Vehicle(4, w) {
		
		cout << "In constuctor with 1 parameters, wheels = "<< w << endl;
	}
	Vehicle(int d, int w) {
		numWheels = w;
		numDoors = d;
		cout << "In constuctor with 2 parameters, doors = " << d << " wheels = " << w << endl;
	}

	~Vehicle() { 
		cout << "In destuctor" << endl;
	}
};

int main(int argc, char **argv)
{
	Vehicle myVihicle(4,2);
	cout << "I made a vehicle" << endl;
	return 0;
}